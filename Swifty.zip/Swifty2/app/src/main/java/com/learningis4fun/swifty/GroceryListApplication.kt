package com.learningis4fun.swifty

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class GroceryListApplication : Application(){
}