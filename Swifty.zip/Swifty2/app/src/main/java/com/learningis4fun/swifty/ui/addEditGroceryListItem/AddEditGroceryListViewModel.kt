package com.learningis4fun.swifty.ui.addEditGroceryListItem

import androidx.lifecycle.ViewModel

class AddEditGroceryListViewModel() : ViewModel() {
}