package com.learningis4fun.swifty.ui.addEditCollection

import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.ViewModel
import com.learningis4fun.swifty.data.Repository

class AddEditCollectionViewModel @ViewModelInject constructor(
    private val repository: Repository
) : ViewModel() {
}