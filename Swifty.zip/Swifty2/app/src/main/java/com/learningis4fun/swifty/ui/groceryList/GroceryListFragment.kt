package com.learningis4fun.swifty.ui.groceryList

import androidx.fragment.app.Fragment

class GroceryListFragment() : Fragment() {
}