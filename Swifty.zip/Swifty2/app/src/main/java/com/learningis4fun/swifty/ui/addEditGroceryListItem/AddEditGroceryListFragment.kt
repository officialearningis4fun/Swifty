package com.learningis4fun.swifty.ui.addEditGroceryListItem

import androidx.fragment.app.Fragment
import com.learningis4fun.swifty.R

class AddEditGroceryListFragment() : Fragment(R.layout.fragment_add_edit_grocery_list) {
}