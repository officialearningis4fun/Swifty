package com.learningis4fun.swifty.ui.collection

import androidx.fragment.app.Fragment
import com.learningis4fun.swifty.R
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CollectionFragment() : Fragment(R.layout.fragment_grocery_collection) {


}