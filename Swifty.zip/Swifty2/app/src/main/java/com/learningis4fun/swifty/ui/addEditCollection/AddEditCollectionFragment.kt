package com.learningis4fun.swifty.ui.addEditCollection

import androidx.fragment.app.Fragment

class AddEditCollectionFragment() : Fragment() {
}